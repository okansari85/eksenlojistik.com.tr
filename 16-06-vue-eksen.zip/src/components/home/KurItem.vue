<template>

</template>

<script>
export default {
  name: "KurItem"
}
</script>

<style scoped>

</style>