<template>

  <div class="row justify-content-between">
    <div class="col-lg-6 text-start">

<!--        <div class="pt-2 pb-4 ">-->
<!--          <strong class="fs-5">Misyonumuz</strong>-->
<!--          <p class="pt-3">Sunmuş olduğumuz tüm  hizmetlerde hizmet kalitesinden ödün vermeyerek müşteri memnuniyeti odaklılığı devam ettirerek sektördeki liderliğini sürdürebilmektir. </p>-->
<!--        </div>-->
<!--        <div class="pt-2 pb-4">-->
<!--          <strong class="fs-5">Vizyonumuz </strong>-->
<!--          <p class="pt-3">Sektöründe fark yaratarak , yenilikçi ve sürekli büyümeye devam ederek  en iyi marka olma yolunda ilerlemek ! </p>-->
<!--        </div>-->

      <div class="row mb-2">
        <div class="col-md-12">
          <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-lg h-md-250 position-relative align-items-center" style="background: #f8f8f8">
            <div class="col-auto d-none d-lg-block">
              <img src="/image/services/m1.png" class="h-100" style="width: 150px;"/>
            </div>
            <div class="col p-4 d-flex flex-column position-static">
              <h3 class="mb-0">Misyonumuz</h3>
              <p class="card-text mb-auto pt-3">Sunmuş olduğumuz tüm  hizmetlerde hizmet kalitesinden ödün vermeyerek müşteri memnuniyeti odaklılığı devam ettirerek sektördeki liderliğini sürdürebilmektir.</p>
            </div>
          </div>
        </div>

        <div class="col-md-12">
          <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-lg h-md-250 position-relative align-items-center" style="background: #f8f8f8">
            <div class="col-auto d-none d-lg-block">
              <img src="/image/services/m2.png" class="h-100" style="width: 150px; object-fit: cover"/>
            </div>
            <div class="col p-4 d-flex flex-column position-static">
              <h3 class="mb-0">Vizyonumuz</h3>
              <p class="card-text mb-auto pt-3">Sektöründe fark yaratarak , yenilikçi ve sürekli büyümeye devam ederek  en iyi marka olma yolunda ilerlemek !</p>
            </div>
          </div>
        </div>

      </div>

    </div>
    <div class="col-lg-5">
      <img src="/image/services/about-team-photo2.jpg" alt="Eksen Services"/>
    </div>
  </div>

</template>

<script>
export default {
  name: "about.vue"
}
</script>

<style scoped>

</style>