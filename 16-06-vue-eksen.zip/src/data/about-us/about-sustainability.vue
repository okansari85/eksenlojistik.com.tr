<template>

  <div class="row justify-content-between">
    <div class="col-lg-6">
      <div class="">
        <h5 class="fs-3 fw-500">
          Sürdürülebilirlik
        </h5>
        <p class="py-3">
          Eksen Lojistik bağlılık ve sorumluluklarının bilinciyle izlediği sürdürülebilir kurumsal politikalara
          bağlıdır.
          EKSEN’in kurumsal felsefesinin ve değer sisteminin merkezi bir direği olarak, bu politikalar hem içeride hem
          dışarıda oryantasyon, kimlik ve istikrar sağlar. Şirketin sürdürülebilir yönetimi, birçok yönden EKSEN'in iş
          stratejisine bağlıdır. Ekolojik yönünün yanı sıra ekonomik ve sosyal boyutları da vardır.
        </p>
      </div>

      <div class="py-3">
        <h5 class="fs-3 fw-500">
          Sürdürülebilirliği teşvik etme hedefi
        </h5>
        <p class="py-3"><strong>Ekonomi: </strong> Büyüme ve başarıya odaklı iş modelleri ile EKSEN, hem şirketin hem de
          çalışanların
          geleceğini garanti altına almaktadır. Kurumsal liderlikte sürdürülebilirlik, şirketin stratejik ve operasyonel
          işlerini, varlığını ve uzun vadede daha da gelişmesini garanti edecek şekilde yönetmek anlamına gelir.</p>

        <p class="py-3"><strong>Ekoloji: </strong> Ürün akışlarını birleştirmek ve gereksiz taşımalardan kaçınmak için
          tüm süreç zincirlerinin verimli organizasyonunun yanı sıra akıllı BT yönlendirme kontrolünün yanı sıra, EKSEN
          çevreyi korumak için tasarlanmış çok sayıda proje başlatmıştır. Ayrıca, lojistikle ilgili alanlara odaklanarak
          sürdürülebilirliğe ilişkin bilimsel araştırmaları teşvik eder.</p>
      </div>

    </div>
    <div class="col-lg-5">
      <img src="/image/services/about-sub-page-photo.png" alt="">
    </div>
  </div>


</template>

<script>
export default {
  name: "about-sustainability"
}
</script>

<style scoped>

</style>