<template>

  <div class="row justify-content-between">
    <div class="col-lg-6">
      <div class="">
        <h5 class="fs-3 fw-500">Hakkımızda</h5>
        <!-- <p class="py-3 d-none">EKSEN ULUSLARARASI LOJİSTİK VE TAŞIMACILIK LTD. ŞTİ. olarak uluslararası karayolu taşımacılığı
          sektöründe 16 yıl boyunca istikrarlı şekilde büyümemizi sürdürerek Romanya hattında marka olma hedefimizi
          gerçekleştirdik.
          Yenilenen araç filomuz, depolama ve gümrükleme hizmetlerimizle beraber parsiyel, komple ve transit tüm
          taşımalarda aynı güven anlayışı ve müşteri odaklı hizmet prensibini devam ettirmekteyiz.
          Her geçen gün nakliye ağımızı tüm Balkan ülkelerine planlı şekilde genişleterek yeni misyonumuz doğrultusunda
          desteklerinizle beraber ilerlemekteyiz.</p> -->


        <p class="pb-3 pe-lg-3">
          Eksen Lojistik , kuruluşundan bu yana uluslararası karayolu taşımacılığı sektöründe istikrarlı şekilde
          büyümesini sürdürerek Romanya hattında marka olma hedefini gerçekleştiren bir lojistik şirketidir.
          <br>
          Sürekli yenilenen araç filosu, depolama ve gümrükleme Hizmetleri ile beraber parsiyel, komple ve transit tüm
          taşımalarda aynı güven anlayışı ve müşteri odaklı hizmet prensibini devam ettirmekteyiz.
          <br>
          Taşımacılık, gümrük , depolama ve tedarik zinciri yönetimi alanında bir çok ülkede en iyi hizmet anlayışı ile
          faaliyet göstermeye ve büyümeye devam eden Eksen Lojistik her zaman müşterilerine entegre, akılcı ve en etkin
          çözümleri sunar.
          <br>
          Türkiye, Romanya Macaristan, Slovakya, Çekya, Polonya Sırbistan ,Hırvatistan Bulgaristan , Slovenya , Almanya,
          Belçika, Hollanda ,İtalya, İspanya ve Portekiz ‘ olmak üzere kapalı alanı 500.000 m’ye ulaşan dağıtım
          merkezleri yanı sıra , rulo sac , sal kasa , minivan ve liftli araç tesllimatları ile hatlarında önde gelen
          lojistik firmalarından biridir.
        </p>

      </div>


      <!-- <div class="py-3 d-none">
        <h5 class="display-6 fw-500">Uluslararası Karayolu Taşımacılığı</h5>
        <p class="py-3">Uluslararası taşımacılıkta başarı, dinamik operasyon kadrosu, global pazara hakimiyet, tecrübeli
          şoför ekibi,
          hatasız depo organizasyonu ve modern ekipmanlar gerektirmektedir.
          Bizler Eksen Ailesi olarak tüm Avrupa’ya 16 seneyi aşkın süredir metal, plastik sanayi, otomotiv, moda-tekstil
          ve gıda gibi başlıca sektörlerde ciddiyet ve titizlikle lojistik hizmeti sunmaktayız.
          Bu hizmetlerimizden önde geleni ana hattımız olan Romanya ve Balkan ülkelerine gerçekleştirdiğimiz kara yolu
          taşımacılığıdır.
          Sevkiyatlar filomuzdaki öz mal araçlarla yapılmakta ve İstanbul & Bükreş’teki ofislerimiz tarafından koordine
          edilmektedir.
          Mega veya standart olmak üzere filomuzda mevcut 50 adet öz mal tenteli tır bulunmaktadır.
          İsteğe göre ekspres teslimat gerektiren küçük hacimli yüklerin nakliyesi minivan araçlarımızla
          gerçekleştirilmektedir.
          Komple araç sevkiyatlarında her gün, parsiyel yüklerde ise haftada ortalama 4 gün İstanbul’da Muratbey ve
          Erenköy, Bükreş’te Expoziti gümrüklerinden çıkışlarımız organize edilmektedir.
          Romanya ve Balkanlar denilince ilk akla gelen lojistik firmalarından biri olmanın sorumluluğunu taşıyarak her
          zamanki hedefimiz, yenilenen ve büyüyen araç filosu ve depomuzla, yüklerinizin zamanında ve hasarsız
          teslimatlarını rekabetçi fiyatlarla sağlamaya devam ettirmektir.</p>
      </div> -->
      <!-- <div class="py-3 d-none">
        <h5 class="display-6 fw-500">Proje Yükü Taşımacılığı</h5>
        <p class="py-3">
          Tenteli tırlara yüklemesi mümkün olmayan gabari dışı veya ağır yüklerin sevkiyatı salkasa ve lowbed treylerler
          gibi özel ekipmanlarla yapılmaktadır.
          Standart ölçü ve ağırlıkları aşması sebebiyle özel yol izinleri ve koşullara göre eskort araçlara tabidir.
          Uygun ekipman tedariği ile ilgili ülkelerin regulasyonları takip edilerek, Türkiye – Avrupa arasında proje
          yükü taşımacılığı hizmetimize devam etmekteyiz.
        </p>
      </div>
      <div class="py-3 d-none">
        <h5 class="display-6 fw-500">Depolama Gümrükleme</h5>
        <p class="py-3">Bükreş ve Çatalca’daki 1000 metrekarelik üstü kapalı alanlarımızda depolama ve dağıtım hizmeti
          vermekteyiz.
          Yükler modern ekipman ve tecrübeli çalışanlarla elleçlenmekte, ihtiyaca ve yük tipine göre gerekli hassasiyet
          gözetilerek istif yapılmaktadır.
          İstanbul - Muratbey & Erenköy, Bükreş - Expoziti gümrüklerinde ithalat, ihracat veya transit işlemlerle ilgili
          gümrükleme servisimiz mevcuttur.</p>
      </div> -->
    </div>
    <div class="col-lg-5">
      <img src="/image/services/eksen_depo2.jpg" alt="IK About" class="pb-5">
      <!-- <Form class="mt-3"/> -->
    </div>
  </div>


</template>

<script>

import Form from '@/components/global/Form'

export default {
  name: "about",
  components: {Form}
}
</script>

<style scoped>

</style>