<template>

  <div class="row justify-content-between">
    <div class="col-lg-6">
      <h5 class="fs-3 fw-500">Gelişiminize Önem Veriyoruz</h5>
      <p class="py-3">
        Sürekli gelişim ve verimlilik hedefi doğrultusunda çalışanlarımızın gelişimlerine büyük önem veriyoruz.
        Çalışanlarımıza yüksek lisans ve doktora programlarına katılmalarını cesaretlendirmek amacıyla destek oluyoruz.
      </p>
      <p>
        Akademi ile eğitim saatlerimizi ve yöntemlerimizi dijital ortamda gerçekleştirmeyi hedefliyoruz.
      </p>
      <p>
        Çalışanlarımızın kişisel ve mesleki/teknik gelişimlerine destek vermek için Dijital İK platformu üzerinden
        online olarak çeşitli eğitimler düzenliyoruz.
      </p>

      <h5 class="fs-3 fw-500">Yetenek ve Performans</h5>
      <p class="py-3">
        Her bir çalışanımızı birer yetenek olarak görüp, potansiyellerini performansa dönüştürmeleri için teşvik
        ediyoruz. Bu doğrultuda çalışanlarımızın bireysel gelişim planlarını oluşturup, güçlü yön ve gelişim alanlarına
        göre eğitimlere dahil ediyoruz.
      </p>
      <p>
        Şirket hedeflerimiz doğrultusunda; ortak bir anlayış oluşturmak ve çalışanlarımızın performanslarının bu
        hedeflere yönlenmesini sağlıyoruz.
      </p>
      <p>
        Performans değerlendirmelerini iş hedefleri ve yetkinlikleri baz alarak yapıyor, yönetici ve çalışanlar arasında
        birebir görüşmeler çerçevesinde, uzlaşma esasına dayalı olarak gerçekleştiriyoruz.
      </p>

    </div>

    <div class="col-lg-5">
      <img src="/image/services/ik-development.png" alt="IK Development">
    </div>

  </div>

</template>

<script>
export default {
  name: "ik-development",
}
</script>

<style scoped>

</style>