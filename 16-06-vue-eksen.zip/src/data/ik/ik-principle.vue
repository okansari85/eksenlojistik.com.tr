<template>

  <div class="row justify-content-between">
    <div class="col-lg-6">
      <h5 class="fs-3 fw-500">Dürüstlük</h5>
      <p class="py-3">
        Eksen Lojistik, tüm faaliyetlerinde doğruluk, şeffaflık ve yüksek iş ahlakı değerlerini her şeyin üzerinde
        görür; birlikte iş yaptığı tüm taraflarımızdan aynı değerlere uygun olarak hareket etmelerini bekleriz.
      </p>

      <h5 class="fs-3 fw-500">Gizlilik</h5>
      <p class="py-3">
        Eksen Lojistik’e ve tüm paydaşlarına ait bilgilerin korunmasına özen gösteririz. Bu bilgileri sadece belirlenmiş
        olan yetkiler dahilinde ilgili kişilerle paylaşırız. <br>
        İnsan Hakları – Fırsat Eşitliği: Hiçbir hal ve koşulda, kişilerin etnik kökenine, cinsiyetine, rengine, ırkına,
        milliyetine, ekonomik durumuna, dinine ve diğer inanışlarına bağlı olarak ayrımcılık yapmayız.
      </p>
    </div>
    
    <div class="col-lg-5">
      <img src="/image/services/ik-new.png" alt="IK Image">
    </div>

  </div>

</template>

<script>
import Form from "@/components/global/Form";
export default {
  name: "ik-principle",
  components: { Form }
}
</script>

<style scoped>

</style>