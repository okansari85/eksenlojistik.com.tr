<template>

  <div class="row justify-content-between">
    <div class="col-md-6">
      <div>
        <h5 class="fs-3 fw-500">Gümrükleme</h5>
        <p class="py-3">Kuruluşumuzdan  bu yana, müşterilerimizin isteği doğrultusunda ,hızlı işlem ve güvenilir takip amacıyla hizmet verdiğimiz tüm ülkelerde gümrükleme çözümleri sunan iş ortaklarımız, müşterilerinin gümrükleme işlemlerine dair yasal yükümlülüklerini onlar adına tam ve eksiksiz yerine getirerek, ithalat ve ihracat işlemlerini standartlaştırılmış süreçler ve uzman  kadrosuyla en hızlı ve güvenilir hizmeti sunmaktadır. </p>

      </div>
    </div>
    <div class="col-md-5">
      <img src="/image/services/services-custom-botton.png" alt="Services Custom">
    </div>
  </div>


</template>

<script>
export default {
  name: "Services-Custom"
}
</script>

<style scoped>

</style>