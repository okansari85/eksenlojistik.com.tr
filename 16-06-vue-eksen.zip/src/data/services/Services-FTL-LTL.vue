<template>

  <div class="row justify-content-between">
    <div class="col-md-6">
      <div>
        <h5 class="fs-3 fw-500">Komple & Parisyel Taşımacılığı</h5>
        <p>
          Günde gerçekleştirmiş olduğumuz komple servislerimizde ; tecrübemiz, esnek kullanıma uygun araç parkımız ile   özmal araçlardan oluşan filomuzla başta otomotiv, tekstil, perakende,  kuru gıda , züccaciye olmak üzere dış ticaretin önemli sektörleri için komple  thalat ve ihracat karayolu taşımacılığı yapıyoruz.
        </p>
        <p>Çatalca’daki ihracat deposu ve direk adreslerden alım hizmeti ile haftanın her
          günü parsiyel sevkiyat gerçekleştiriyoruz. İhtiyaca yönelik depomuz , güvenilir ve profesyonel  ekibimiz  ile sağladığımız yükleri zamanında, ve eksiksiz   şekilde yerlerine ulaştırıyor ve  müşteri temsilcilerimiz ilei kesintisiz olarak erişim imkanı sağlıyoruz.</p>
      </div>
    </div>
    <div class="col-md-5">
      <img src="/image/services/services-parsiyel-bottom1.png" alt="Services Parsiyel">
    </div>
  </div>

  <div class="row">

  </div>


</template>

<script>
export default {
  name: "Services-FTL-LTL"
}
</script>

<style scoped>

</style>