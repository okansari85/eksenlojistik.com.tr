<template>

  <div class="row justify-content-between">
    <div class="col-md-6">
      <div>
        <h5 class="fs-3 fw-500">Karayolu Taşımacılığı</h5>
        <p class="py-3">Tümü EURO 5 ve EURO 6 standartlarında çekicilerden oluşan geniş ve çevreci özmal filosuyla farklı nitelikteki (tenteli/ havuzlu / minivan / sal kasa ) araçlarımız ile %100 müşteri memnuniyeti ve esnek fiyatlar ile  kusursuz bir karayolu taşımacılığı hizmeti sunuyoruz.  </p>
        <p>
          Kısa transit süreleri belirleyerek güzergah oluşturup hızlı ve akılcı çözümler ile müşterilerimize  en iyi  hizmet kalitesini veriyoruz.
        </p>
      </div>
    </div>
    <div class="col-md-5">
      <img src="/image/services/services-domestic-bottom.png" alt="Services Domestic">
    </div>
  </div>


</template>

<script>
export default {
  name: "Services-Highway"
}
</script>

<style scoped>

</style>