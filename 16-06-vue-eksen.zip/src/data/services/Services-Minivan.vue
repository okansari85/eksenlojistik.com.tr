<template>

  <div class="row justify-content-between">
    <div class="col-md-6">
      <div>
        <h5 class="fs-3 fw-500">Minivan Taşımacılık</h5>
        <p class="py-3">Tüm Avrupa ülkelerine daha hızlı Sevkiyat imkanı ile Avrupa’nın tüm bölgelerine en hızlı şekilde teslimat yapmaktayız.
        Express taşıma hizmetimiz, müşterilerimize 1.3 ton ağırlığa kadar olan taşımalarında kapıdan kapıya teslimat hizmeti sunmaktayız.</p>
      </div>
    </div>
    <div class="col-md-5">
      <img src="/image/services/services-ekspress-bottom.png" alt="Services Minivan">
    </div>
  </div>


</template>

<script>
export default {
  name: "Services-Minivan"
}
</script>

<style scoped>

</style>