<template>

  <div class="row justify-content-between">
    <div class="col-md-6">
      <div>
        <h5 class="fs-3 fw-500">Depolama Hizmeti </h5>
        <p class="py-3">Eksen  Lojistik olarak, gümrüksüz, sahamızda müşteriye özel lojistik alanı  ve aktarma araçlarımız  ile çok yönlü ve entegre depolama hizmetleri veriyoruz.</p>
        <p>Ürünün depoya ilk girişinden sevkiyata kadar olan tüm aşamaların elektronik ortamda takip edilmesi ve  ürünlerin özelliklerine göre uygun koşullarda depolanmasını sağlıyoruz. </p>
        <p>
          Müşterileirmizin ihtiyaçlarına göre özelleştirilmiş otomatik çözümler ille yüksek hizmet kalitesini sunmak amacımızdır. 
        </p>
        <p>
          Depomuzda bulunan online izleme ve takip sistemi sayesinde tüm bilgilere erişim sağlayabiliyorsunuz.
Hasarlı- kayıp malzemeler için prosedürler, raporlamalar, bloke işlemleri yine profesyonel olarak tutulmaktadır
        </p>
      </div>
    </div>
    <div class="col-md-5">
      <img src="/image/services/depoalt.jpg" alt="Depo Alt">
    </div>
  </div>


</template>

<script>
export default {
  name: "Services-Store"
}
</script>

<style scoped>

</style>