<template>
  <footer class='px-lg-5 pt-4'>
    <div class="container-fluid px-3 px-lg-5 py-3">
      <!-- <div class="row justify-content-between align-items-center pb-4">
        <div class="col-lg-3">
          
        </div>
      </div> -->
      <div class="row pb-3 pt-md-4">
        <div class="col-lg-3">
          <div class="pb-4">
              <img src="/image/global/eksen_logo.png" alt="Footer Logo" width="300" class="d-none d-lg-block"/>
          </div>
          <div class="col-md-3 pt-3 pt-lg-0">
          <i class='bi bi-instagram'></i>
          <i class='bi bi-linkedin ms-2'></i>
        </div>
        </div>
        <div class="col-sm-6 col-lg-2">
          <ul class="list-unstyled fs-08">
            <li>Büyükdere Cad. No.62</li>
            <li>Kat2 Fulya Mah.</li>
            <li>Mecidiyeköy Şişli</li>
            <li><strong>İstanbul</strong></li>
          </ul>
        </div>
        <div class="col-sm-6 col-lg-3 pt-4 pt-sm-0">
          <ul class="list-unstyled">
            <li class="fs-08"><a href="tel:902122122849"><i class="bi bi-telephone-fill pe-2"></i> +90 212 212 28 49</a></li>
            <li class="fs-08"><a href="tel:902122122515"><i class="bi bi-telephone-fill pe-2"></i> +90 212 212 25 15</a></li>
            <li class="fs-08"><a href="tel:908508116404"><i class="bi bi-telephone-fill pe-2"></i> +90 850 811 64 04</a></li>
            <li class="fs-08 pt-2"><a href="mailto:info@eksenlojistik.com.tr"><i class="bi bi-envelope-fill pe-2"></i> info@eksenlojistik.com.tr</a></li>
          </ul>
        </div>
        <div class="col-lg-4 pt-4 pt-md-0">
          <label For="" class="d-block">Bültenimize kayıt olun</label>
<!--          <input type="text" placeholder="E-mail Adresi" class="py-3 my-3 form-control"/>-->
          <div class="input-group mb-3">
            <input type="text" class="form-control" placeholder="E-mail Adresi">
            <button class="btn btn-outline-secondary bg-dark text-white" type="submit" id="button-addon2">Gönder</button>
          </div>
          <span class="fs-08 py-3 d-block">Bu formu göndererek şartlar ve koşullarımızı <a href="#!" class="text-decoration-underline fw-bold">kabul etmiş olursunuz</a></span>
        </div>
      </div>
      <div class="d-flex justify-content-between align-items-center">
        <div class="col-lg-4">
          <ul class="d-sm-flex justify-content-between justify-content-sm-start pb-3 fs-08">
            <li class="me-sm-4 "><a href="" data-bs-toggle="modal" data-bs-target="#modal-sartlar" class="fw-500">Şartlar ve Koşullar</a></li>
            <li class="me-sm-4 py-2 py-sm-0"><a href="" data-bs-toggle="modal" data-bs-target="#modal-yasal-uyari" class="fw-500">Yasal Uyarı</a></li>
            <li class="me-sm-4"><a href="" data-bs-toggle="modal" data-bs-target="#modal-veri-gizliligi" class="fw-500">Veri Gizliliği</a></li>
          </ul>
        </div>
        <!-- <div class="col-lg-3">
          <img src="/image/global/icon/iso-9001.png" alt="ISO icon" />
        </div> -->
      </div>
    </div>
  </footer>




  <!--  Modal  -->

<!-- Şartlar ve Koşullar -->
<div class="modal fade" id="modal-sartlar" tabindex="-1" aria-modal="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Şartlar ve Koşullar</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <div id="content" class="container" style="margin-top:0;min-height:0px"><p><b>ÜYELİK SÖZLEŞMESİ</b><br><br><b>Lütfen sitemizi kullanmadan evvel bu ‘site kullanım şartları’nı dikkatlice okuyunuz.</b><br><br>
              Bu alışveriş sitesini kullanan ve alışveriş yapan müşterilerimiz aşağıdaki şartları kabul etmiş varsayılmaktadır: <br>
              Sitemizdeki web sayfaları ve ona bağlı tüm sayfalar (‘site’) www.eksenlojistik.com.tr adresindeki Hediye Ürün Al firmasına (‘Firma) aittir ve onun tarafından işletilir. Sizler (‘Kullanıcı’) sitede sunulan tüm hizmetleri kullanırken aşağıdaki şartlara tabi olduğunuzu, sitedeki hizmetten yararlanmakla ve kullanmaya devam etmekle; Bağlı olduğunuz yasalara göre sözleşme imzalama hakkına, yetkisine ve hukuki ehliyetine sahip ve 18 yaşın üzerinde olduğunuzu, bu sözleşmeyi okuduğunuzu, anladığınızı ve sözleşmede yazan şartlarla bağlı olduğunuzu kabul etmiş sayılırsınız.<br><br>
              İşbu sözleşme süresiz olmakla, taraflara sözleşme konusu site ile ilgili hak ve yükümlülükler yükler ve taraflar işbu sözleşmeyi online veya yazık olarak kabul ettiklerinde/onayladıklarında bahsi geçen hak ve yükümlülükleri eksiksiz, doğru, zamanında, işbu sözleşmede talep edilen şartlar dâhilinde yerine getireceklerini beyan ve taahhüt ederler.
              <br><br><b>1. SORUMLULUKLAR</b><br><br>
              1.1.	Firma, fiyatlar ve sunulan ürün ve hizmetler üzerinde değişiklik yapma hakkını her zaman saklı tutar. <br><br>
              1.2.	Firma, üyenin sözleşme konusu hizmetlerden, teknik arızalar dışında yararlandırılacağını kabul ve taahhüt eder. <br><br>
              1.3.	Kullanıcı, sitenin kullanımında tersine mühendislik yapmayacağını ya da bunların kaynak kodunu bulmak veya elde etmek amacına yönelik herhangi bir başka işlemde bulunmayacağını aksi halde ve 3. Kişiler nezdinde doğacak zararlardan sorumlu olacağını, hakkında hukuki ve cezai işlem yapılacağını peşinen kabul eder. <br><br>
              1.4.	Kullanıcı, siteye üye olurken vermiş olduğu eksik ve yanlış bilgi dolayısıyla uğrayacağı zararlardan sadece kendisinin sorumlu olacağını, yanlış bilgi vermesi durumunda ve işbu sözleşmenin Üye tarafından ihlali halinde, firmanın tek taraflı olarak herhangi bir ihbara ve ihtara ihtiyaç duymaksızın üyeliğini sona erebileceğini kabul eder. <br><br>
              1.5.	Firma tarafından internet sitesinin iyileştirilmesi, geliştirilmesine yönelik olarak ve/veya yasal mevzuat çerçevesinde siteye erişmek için kullanılan Internet servis sağlayıcısının adı ve Internet Protokol (IP) adresi, Siteye erişilen tarih ve saat, sitede bulunulan sırada erişilen sayfalar ve siteye doğrudan bağlanılmasını sağlayan Web sitesinin Internet adresi gibi birtakım bilgiler toplanabilir. Kullanıcı, bu bilgilerin toplanmasını kabul eder. <br><br>
              1.6.	Kullanıcı, site içindeki faaliyetlerinde, sitenin herhangi bir bölümünde veya iletişimlerinde genel ahlaka ve adaba aykırı, kanuna aykırı, 3. Kişilerin haklarını zedeleyen, yanıltıcı, saldırgan, müstehcen, pornografik, kişilik haklarını zedeleyen, telif haklarına aykırı, yasa dışı faaliyetleri teşvik eden içerikler üretmeyeceğini, paylaşmayacağını kabul eder. Aksi halde oluşacak zarardan tamamen kendisi sorumludur ve bu durumda ‘Site’ yetkilileri, bu tür hesapları askıya alabilir, sona erdirebilir, yasal süreç başlatma hakkını saklı tutar. Bu sebeple yargı mercilerinden etkinlik veya kullanıcı hesapları ile ilgili bilgi talepleri gelirse, mercilerle bu bilgileri paylaşma hakkını saklı tutar. 
              <br><br>
              1.7.	Sitenin üyelerinin birbirleri veya üçüncü şahıslarla olan ilişkileri kendi sorumluluğundadır. <br><br><b>2. FİKRİ MÜLKİYET HAKLARI</b><br><br>
              2.1. İşbu Site’de yer alan ünvan, işletme adı, marka, patent, logo, tasarım, bilgi ve yöntem gibi tescilli veya tescilsiz tüm fikri mülkiyet hakları site işleteni ve sahibi firmaya veya belirtilen ilgilisine ait olup, ulusal ve uluslararası hukukun koruması altındadır. İşbu Site’nin ziyaret edilmesi veya bu Site’deki hizmetlerden yararlanılması söz konusu fikri mülkiyet hakları konusunda hiçbir hak vermez. <br><br>
              2.2. Site’de yer alan bilgiler hiçbir şekilde çoğaltılamaz, yayınlanamaz, kopyalanamaz, sunulamaz ve/veya aktarılamaz. Site’nin bütünü veya bir kısmı diğer bir internet sitesinde izinsiz olarak kullanılamaz. Böyle bir ihlal durumunda, kullanıcı,üçüncü kişilerin uğradıkları zararlardan dolayı firmadan talep edilen tazminat miktarını ve mahkeme masrafları ve avukatlık ücreti de dahil ancak bununla sınırlı olmamak üzere diğer her türlü yükümlülükleri karşılamakla sorumlu olacaklardır. <br><br><b>3. GİZLİ BİLGİ</b><br><br>
              3.1. Firma, site üzerinden kullanıcıların ilettiği kişisel bilgileri 3. Kişilere açıklamayacaktır. Bu kişisel bilgiler; kişi adı-soyadı, adresi, telefon numarası, cep telefonu, e-posta adresi gibi Kullanıcı’yı tanımlamaya yönelik her türlü diğer bilgiyi içermekte olup, kısaca ‘Gizli Bilgiler’ olarak anılacaktır. <br><br>
              3.2. Kullanıcı, tanıtım, reklam, kampanya, promosyon, duyuru vb. pazarlama faaliyetleri kapsamında kullanılması ile sınırlı olmak üzere, Site’nin sahibi olan firmanın kendisine ait iletişim, portföy durumu ve demografik bilgilerini iştirakleri ya da bağlı bulunduğu grup şirketleri ile paylaşmasına, kendisi veya iştiraklerine yönelik bu bağlamda elektronik ileti almaya onay verdiğini kabul ve beyan eder. Bu kişisel bilgiler firma bünyesinde müşteri profili belirlemek, müşteri profiline uygun promosyon ve kampanyalar sunmak ve istatistiksel çalışmalar yapmak amacıyla kullanılabilecektir. <br><br>
              3.3.Kullanıcı, işbu sözleşme ile vermiş olduğu onayı, hiçbir gerekçe açıklamaksızın iptal etmek hakkını sahiptir. İptal işlemini firma, derhal işleme alıp, 3 (üç) iş günü içerisinde kullanıcıyı elektronik ileti almaktan imtina eder. <br><br>
              3.4.Gizli Bilgiler, ancak resmi makamlarca usulü dairesinde bu bilgilerin talep edilmesi halinde ve yürürlükteki emredici mevzuat hükümleri gereğince resmi makamlara açıklama yapılmasının zorunlu olduğu durumlarda resmi makamlara açıklanabilecektir. <br><br><b>4. GARANTİ VERMEME:</b><br><br>
              İşbu sözleşme maddesi uygulanabilir kanunun izin verdiği azami ölçüde geçerli olacaktır. Firma tarafından sunulan hizmetler "olduğu gibi” ve "mümkün olduğu” temelde sunulmakta ve pazarlanabilirlik, belirli bir amaca uygunluk veya ihlal etmeme konusunda tüm zımni garantiler de dâhil olmak üzere hizmetler veya uygulama ile ilgili olarak (bunlarda yer alan tüm bilgiler dâhil) sarih veya zımni, kanuni veya başka bir nitelikte hiçbir garantide bulunmamaktadır. <br><br><b>5. KAYIT VE GÜVENLİK</b><br><br>
              Kullanıcı, doğru, eksiksiz ve güncel kayıt bilgilerini vermek zorundadır. Aksi halde bu Sözleşme ihlal edilmiş sayılacak ve Kullanıcı bilgilendirilmeksizin hesap kapatılabilecektir.
              Kullanıcı, site ve üçüncü taraf sitelerdeki şifre ve hesap güvenliğinden kendisi sorumludur. Aksi halde oluşacak veri kayıplarından ve güvenlik ihlallerinden veya donanım ve cihazların zarar görmesinden Firmasorumlu tutulamaz. <br><br><b>6. MÜCBİR SEBEP</b><br><br>
              Tarafların kontrolünde olmayan; tabii afetler, yangın, patlamalar, iç savaşlar, savaşlar, ayaklanmalar, halk hareketleri, seferberlik ilanı, grev, lokavt ve salgın hastalıklar, altyapı ve internet arızaları, elektrik kesintisi gibi sebeplerden (aşağıda birlikte "Mücbir Sebep” olarak anılacaktır.) dolayı sözleşmeden doğan yükümlülükler taraflarca ifa edilemez hale gelirse, taraflar bundan sorumlu değildir. Bu sürede Taraflar’ın işbu Sözleşme’den doğan hak ve yükümlülükleri askıya alınır. <br><br><b>7. SÖZLEŞMENİN BÜTÜNLÜĞÜ VE UYGULANABİLİRLİK</b><br><br>
              İşbu sözleşme şartlarından biri, kısmen veya tamamen geçersiz hale gelirse, sözleşmenin geri kalanı geçerliliğini korumaya devam eder. <br><br><b>8. SÖZLEŞMEDE YAPILACAK DEĞİŞİKLİKLER</b><br><br>
              Firma, dilediği zaman sitede sunulan hizmetleri ve işbu sözleşme şartlarını kısmen veya tamamen değiştirebilir. Değişiklikler sitede yayınlandığı tarihten itibaren geçerli olacaktır. Değişiklikleri takip etmek Kullanıcı’nın sorumluluğundadır. Kullanıcı, sunulan hizmetlerden yararlanmaya devam etmekle bu değişiklikleri de kabul etmiş sayılır. <br><br><b>9. TEBLİGAT</b><br><br>
              İşbu Sözleşme ile ilgili taraflara gönderilecek olan tüm bildirimler, Firma’nın bilinen e-posta adresi ve kullanıcının üyelik formunda belirttiği e-posta adresi vasıtasıyla yapılacaktır. Kullanıcı, üye olurken belirttiği adresin geçerli tebligat adresi olduğunu, değişmesi durumunda 5 gün içinde yazılı olarak diğer tarafa bildireceğini, aksi halde bu adrese yapılacak tebligatların geçerli sayılacağını kabul eder. <br><br><b>10. DELİL SÖZLEŞMESİ</b><br><br>
              Taraflar arasında işbu sözleşme ile ilgili işlemler için çıkabilecek her türlü uyuşmazlıklarda Taraflar’ın defter, kayıt ve belgeleri ile ve bilgisayar kayıtları ve faks kayıtları 6100 sayılı Hukuk Muhakemeleri Kanunu uyarınca delil olarak kabul edilecek olup, kullanıcı bu kayıtlara itiraz etmeyeceğini kabul eder. <br><br><b>11. UYUŞMAZLIKLARIN ÇÖZÜMÜ</b><br><br>
              İşbu Sözleşme’nin uygulanmasından veya yorumlanmasından doğacak her türlü uyuşmazlığın çözümünde İstanbul (Merkez) Adliyesi Mahkemeleri ve İcra Daireleri yetkilidir.</p><p><b>12. İLETİŞİM İZNİ</b></p><p>Kişi ( firma, şahıs vb.) üye olduğu takdirde kampanya, indirim, bilgilendirme vb. tüm sms, mail vb. iletişim yolları ile yapılacak bildirimleri onaylamış sayılmaktadır.</p></div>
            </div>
        </div>
    </div>
</div>

<!-- Yasal Uyarı -->
<div class="modal fade" id="modal-yasal-uyari" tabindex="-1" aria-modal="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Yasal Uyarı</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <div class="container">
              <p>www.eksenlojistik.com.tr web sitesinde yer alan herhangi bir malzeme, bilgi, görsel veya projeyi kullanmanızdan kaynaklanacak her tür sorumluluk tarafınıza ait olacaktır.</p> <p>Eksen Lojistik; www.eksenlojistik.com.tr web sitesinde yayınlanmış bilgiler ya da bilgilere dayanılarak yapılan işlemlerden veya siteye ulaşılamamasından doğan ve doğacak zarar ve/veya kayıplardan dolayı hiçbir şekilde sorumluluk kabul etmez. Bu web sitesinin yayınlanması, hiçbir kişi ve/veya kuruluşa herhangi bir konuda, herhangi bir taahhüt içermemektedir. Sitede yer alan bilgiler ışığında verilecek her türlü kararlar ile ilgili tüm sorumluluk, bu siteyi ziyaret eden kişiye aittir.</p> <p>www.eksenlojistik.com.tr web sitesine veya bu siteden bağlantı yapılarak ulaşılan herhangi bir web sitesine girilmesi veya bunların kullanımından doğabilecek doğrudan veya dolaylı kayıp veya zararlardan, Eksen Lojistik sorumlu tutulamaz.</p> 
              </div>

            </div>
        </div>
    </div>
</div>

<!-- Gizlilik Politikası -->
<div class="modal fade" id="modal-veri-gizliligi" tabindex="-1" aria-modal="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Veri Gizliliği</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="content" class="container" style="margin-top:0;min-height:0px"><b>1) Kişisel verilerin toplanmasının yasal dayanağı</b><br><br>
                Müşterilerimizin kişisel verilerinin kullanılması konusunda çeşitli kanunlarda düzenlemeler bulunmaktadır. En başta KVKK ile kişisel verilerin korunması esasları belirlenmiştir. Ayrıca 6563 Sayılı Elektronik Ticaretin Düzenlenmesi Hakkında Kanun da kişisel verilerin korunmasına ilişkin hüküm içermektedir. 5237 Sayılı Türk Ceza Kanunu hükümleri yoluyla da kişisel verilerin korunması için bazı hallerde cezai yaptırımlar öngörülmüştür.<br><br>
                Diğer yandan, 6502 sayılı Tüketicinin Korunması Hakkında Kanun ve Mesafeli Sözleşmeler Yönetmeliği’nden doğan yükümlülüklerimizin ifası amacıyla verilerin toplanması ve kullanılması gerekmektedir.<br><br><b>2) Kişisel verilerin toplanmasında kullanılan yöntemler </b><br><br>
                a) www.eksenlojistik.com.tr web sitesinden veya mobil uygulamalardan işlem yapan müşterilerimizin verdikleri veriler, müşterilerimizin rızaları ve mevzuat hükümleri uyarınca hediyeurunal tarafından işlenmektedir.<br><br>
                b) hediyeurunal’a ait olan www.eksenlojistik.com.tr web sitesi çerez (cookie) kullanan bir sitedir. Çerez; kullanılmakta olan cihazın internet tarayıcısına ya da sabit diskine depolanarak söz konusu cihazın tespit edilmesine olanak tanıyan, çoğunlukla harf ve sayılardan oluşan bir dosyadır.<br><br>
                c) www.eksenlojistik.com.tr ziyaretçilerine daha iyi hizmet verebilmek amacıyla ve yasal yükümlülüğü çerçevesinde, işbu Kişisel Verilerin Korunması Hakkında Açıklama metninde belirlenen amaçlar ve kapsam dışında kullanılmamak kaydı ile gezinme bilgilerinizi toplayacak, işleyecek, üçüncü kişilerle paylaşacak ve güvenli olarak saklayacaktır.<br><br>
                d) www.eksenlojistik.com.tr çerezleri; günlük dosyaları, boş gif dosyaları ve/veya üçüncü taraf kaynakları yoluyla topladığı bilgileri tercihlerinizle ilgili bir özet oluşturmak amacıyla depolar. www.eksenlojistik.com.tr size özel tanıtım yapmak, promosyonlar ve pazarlama teklifleri sunmak, web sitesinin veya mobil uygulamanın içeriğini size göre iyileştirmek ve/veya tercihlerinizi belirlemek amacıyla; site üzerinde gezinme bilgilerinizi ve/veya site üzerindeki kullanım geçmişinizi izleyebilmektedir.<br><br>
                e) www.eksenlojistik.com.tr çevrimiçi ve çevrimdışı olarak toplanan bilgiler gibi farklı yöntemlerle veya farklı zamanlarda site üzerinde sizden toplanan bilgileri eşleştirebilir ve bu bilgileri üçüncü taraflar gibi başka kaynaklardan alınan bilgilerle birlikte kullanabilir.<br><br>
                f) www.eksenlojistik.com.tr mobil uygulamasında oturum çerezleri ve kalıcı çerezler kullanmaktadır. Oturum kimliği çerezi, tarayıcınızı kapattığınızda sona erer. Kalıcı çerez ise sabit diskinizde uzun bir süre kalır. İnternet tarayıcınızın "yardım" dosyasında verilen talimatları izleyerek veya “www.allaboutcookies.org” veya “www.youronlinechoices.eu” adresini ziyaret ederek kalıcı çerezleri kaldırabilir ve hem oturum çerezlerini hem de kalıcı çerezleri reddedebilirsiniz. Kalıcı çerezleri veya oturum çerezlerini reddederseniz, web sitesini, mobil uygulamayı kullanmaya devam edebilirsiniz fakat web sitesinin, mobil uygulamanın tüm işlevlerine erişemeyebilirsiniz veya erişiminiz sınırlı olabilir.<br><br><b>3) İnternet Sitesi Çerezlerin kullanımı</b><br><br>
                a) www.eksenlojistik.com.tr çerezleri; yaptığınız tercihleri hatırlamak ve web sitesi/mobil uygulama kullanımınızı kişiselleştirmek için kullanır. Bu kullanım parolanızı kaydeden ve web sitesi/mobil uygulama oturumunuzun sürekli açık kalmasını sağlayan, böylece her ziyaretinizde birden fazla kez parola girme zahmetinden kurtaran çerezleri ve web sitesi/mobil uygulamaya daha sonraki ziyaretlerinizde sizi hatırlayan ve tanıyan çerezleri içerir.<br><br>
                b) www.eksenlojistik.com.tr web sitesine nereden bağlandığınız, web sitesi/mobil uygulama üzerinde hangi içeriği görüntülediğiniz ve ziyaretinizin süresi gibi web sitesini/mobil uygulamayı nasıl kullandığınızın izlenmesi dahil olmak üzere; web sitesini/mobil uygulamayı nasıl kullandığınızı belirlemek için kullanır.<br><br>
                c) www.eksenlojistik.com.tr web sitesindeki çerezler ilgi alanlarınıza ve size daha uygun içerik ve reklamları sunmak için reklam/tanıtım amacıyla kullanılır. Bu şekilde, web sitesini, mobil uygulamasını kullandığınızda size daha uygun içerikleri, kişiye özel kampanya ve ürünleri sunar ve daha önceden istemediğinizi belirttiğiniz içerik veya fırsatları bir daha sunmaz.<br><br><b>4) İnternet Sitesi üçüncü taraf çerezlerini reklam ve yeniden hedefleme için kullanımı</b><br><br>
                www.eksenlojistik.com.tr web sitesi çerezleri ayrıca; arama motorlarını, web sitesi, mobil uygulamasını ve/veya web sitesinin reklam verdiği internet sitelerini ziyaret ettiğinizde ilginizi çekebileceğini düşündüğü reklamları size sunabilmek için “reklam teknolojisini” devreye sokmak amacıyla kullanabilir. Reklam teknolojisi, size özel reklamlar sunabilmek için web sitesine/mobil uygulamaya ve web sitesinin reklam verdiği web sitelerine/mobil uygulamalarına yaptığınız önceki ziyaretlerle ilgili bilgileri kullanır. Bu reklamları sunarken, web sitesinin sizi tanıyabilmesi amacıyla tarayıcınıza benzersiz bir üçüncü taraf çerezi yerleştirilebilir. İnternet tarayıcınızın "yardım" dosyasında verilen talimatları izleyerek veya “www.allaboutcookies.org” ya da “www.youronlinechoices.eu” adresini ziyaret ederek kalıcı çerezleri kaldırabilir ve hem oturum çerezlerini hem de kalıcı çerezleri reddedebilirsiniz.<br><br><b>5) Kişisel verilerin toplanma amaçları</b><br><br>
                hediyeurunal, mevzuatın izin verdiği durumlarda ve ölçüde kişisel bilgilerinizi kaydedebilecek, saklayabilecek, güncelleyebilecek, üçüncü kişilere açıklayabilecek, devredebilecek, sınıflandırabilecek ve işleyebilecektir.<br><br>
                Kişisel verileriniz şu amaçlarla kullanılmaktadır;<br><br>
                a) web sitesi/mobil uygulamalar üzerinden alışveriş yapanın/yaptıranın kimlik bilgilerini teyit etmek,<br><br>
                b) iletişim için adres ve diğer gerekli bilgileri kaydetmek,<br><br>
                c) mesafeli satış sözleşmesi ve Tüketicinin Korunması Hakkında Kanun’un ilgili maddeleri tahtında akdettiğimiz sözleşmelerin koşulları, güncel durumu ve güncellemeler ile ilgili müşterilerimiz ile iletişime geçmek, gerekli bilgilendirmeleri yapabilmek,<br><br>
                d) elektronik (internet/mobil vs.) veya kağıt ortamında işleme dayanak olacak tüm kayıt ve belgeleri düzenlemek,<br><br>
                e) mesafeli satış sözleşmesi ve Tüketicinin Korunması Hakkında Kanun’un ilgili maddeleri tahtında akdettiğimiz sözleşmeler uyarınca üstlenilen yükümlülükleri ifa etmek,<br><br>
                f) kamu güvenliğine ilişkin hususlarda talep halinde ve mevzuat gereği kamu görevlilerine bilgi verebilmek,<br><br>

                g) müşterilerimize daha iyi bir alışveriş deneyimini sağlamak, “müşterilerimizin ilgi alanlarını dikkate alarak” müşterilerimizin ilgilenebileceği ürünlerimiz hakkında müşterilerimize bilgi verebilmek, kampanyaları aktarmak,<br><br>
                h) müşteri memnuniyetini artırmak, web sitesi ve/veya mobil uygulamalardan alışveriş yapan müşterilerimizi tanıyabilmek ve müşteri çevresi analizinde kullanabilmek, çeşitli pazarlama ve reklam faaliyetlerinde kullanabilmek ve bu kapsamda anlaşmalı kuruluşlar aracılığıyla elektronik ortamda ve/veya fiziki ortamda anketler düzenlemek,<br><br>
                i) anlaşmalı kurumlarımız ve çözüm ortaklarımız tarafından müşterilerimize öneri sunabilmek, hizmetlerimizle ilgili müşterilerimizi bilgilendirebilmek,<br><br>
                j) hizmetlerimiz ile ilgili müşteri şikayet ve önerilerini değerlendirebilmek,<br><br>
                k) yasal yükümlülüklerimizi yerine getirebilmek ve yürürlükteki mevzuattan doğan haklarımızı kullanabilmek.<br><br><b>6) Kişisel verilerinizin korunması</b><br><br>
                hediyeurunal ile paylaşılan kişisel veriler, hediyeurunal gözetimi ve kontrolü altındadır. hediyeurunal, yürürlükteki ilgili mevzuat hükümleri gereğince bilginin gizliliğinin ve bütünlüğünün korunması amacıyla gerekli organizasyonu kurmak ve teknik önlemleri almak ve uyarlamak konusunda veri sorumlusu sıfatıyla sorumluluğu üstlenmiştir. Bu konudaki yükümlülüğümüzün bilincinde olarak veri gizliliğini konu alan uluslararası ve ulusal teknik standartlara uygun surette periyodik aralıklarda sızma testleri yaptırılmakta ve bu kapsamda veri işleme politikalarımızı her zaman güncellediğimizi bilginize sunarız.<br><br><b>7) Kişisel verilerinizin paylaşımı </b><br><br>
                Müşterilerimize ait kişisel verilerin üçüncü kişiler ile paylaşımı, müşterilerin izni çerçevesinde gerçekleşmekte ve kural olarak müşterimizin onayı olmaksızın kişisel verileri üçüncü kişilere aktarılmamaktadır.<br><br>
                Bununla birlikte, yasal yükümlülüklerimiz nedeniyle ve bunlarla sınırlı olmak üzere mahkemeler ve diğer kamu kurumları ile kişisel veriler paylaşılmaktadır. Ayrıca, taahhüt ettiğimiz hizmetleri sağlayabilmek ve verilen hizmetlerin kalite kontrolünü yapabilmek için anlaşmalı üçüncü kişilere kişisel veri aktarımı yapılmaktadır.<br><br>
                Üçüncü kişilere veri aktarımı sırasında hak ihlallerini önlemek için gerekli teknik ve hukuki önlemler alınmaktadır. Bununla birlikte, kişisel verileri alan üçüncü kişinin veri koruma politikalarından dolayı ve üçüncü kişinin sorumluluğundaki risk alanında meydana gelen ihlallerden hediyeurunal sorumlu değildir.<br><br>
                Kişisel verileriniz hediyeurunal’nın hissedarlarıyla, doğrudan/dolaylı yurtiçi/yurtdışı iştiraklerimize, faaliyetlerimizi yürütebilmek için işbirliği yaptığımız program ortağı kurum, kuruluşlarla, verilerin bulut ortamında saklanması hizmeti aldığımız yurtiçi/yurtdışı kişi ve kurumlarla, müşterilerimize ticari elektronik iletilerin gönderilmesi konusunda anlaşmalı olduğumuz yurtiçi/yurtdışındaki kuruluşlarla, Bankalararası Kart Merkeziyle, anlaşmalı olduğumuz bankalarla ve sizlere daha iyi hizmet sunabilmek ve müşteri memnuniyetini sağlayabilmek için çeşitli pazarlama faaliyetleri kapsamında yurtiçi ve yurtdışındaki çeşitli ajans, reklam şirketleri ve anket şirketleriyle ve yurtiçi/yurtdışı diğer üçüncü kişilerle ve ilgili iş ortaklarımızla paylaşılabilmektedir.<br><br><b>8) Kişisel Verilerin Korunması Kanunu’ndan doğan haklarınız </b><br><br>
                KVKK uyarınca kişisel verilerinizin;<br><br>
                a) işlenip işlenmediğini öğrenme,<br><br>
                b) işlenmişse bilgi talep etme,<br><br>
                c) işlenme amacını ve amacına uygun kullanılıp kullanılmadığını öğrenme,<br><br>
                d) yurt içinde / yurt dışında aktarıldığı 3. kişileri bilme,<br><br>
                e) eksik / yanlış işlenmişse düzeltilmesini isteme,<br><br>
                f) KVKK’nın 7. maddesinde öngörülen şartlar çerçevesinde silinmesini / yok edilmesini isteme,<br><br>
                g) aktarıldığı 3. kişilere yukarıda sayılan (d) ve (e) bentleri uyarınca yapılan işlemlerin bildirilmesini isteme,<br><br>
                h) münhasıran otomatik sistemler ile analiz edilmesi nedeniyle aleyhinize bir sonucun ortaya çıkmasına itiraz etme,<br><br>
                i) KVKK’ya aykırı olarak işlenmesi sebebiyle zarara uğramanız hâlinde zararın giderilmesini talep etme haklarına sahip olduğunuzu hatırlatmak isteriz.<br><br>
                j) Başvuru formu için tıklayınız.<br><br><b>9) Kişisel verilerle ilgili mevzuat değişiklikleri</b><br><br>
                KVKK uyarınca sahip olduğunuz haklar hediyeurunal’nın yükümlülükleridir. Kişisel verilerinizi bu bilinçle ve mevzuatın gerektirdiği ölçüde işlediğimizi, yasal değişikliklerin olması halinde sayfamızda yer alan bu bilgileri yeni mevzuata uygun güncelleyeceğimizi, yapılan güncellemeleri de bu sayfa üzerinden her zaman kolaylıkla takip edebileceğinizi size bildirmek isteriz.<br><br><b>10) Verinin güncel ve doğru tutulması ve saklanması</b><br><br>
                KVKK’nın 4. maddesi uyarınca hediyeurunal’nın kişisel verilerinizi doğru ve güncel olarak tutma yükümlülüğü bulunmaktadır. Bu kapsamda hediyeurunal’nın yürürlükteki mevzuattan doğan yükümlülüklerini yerine getirebilmesi için müşterilerimizin hediyeurunal’la doğru ve güncel verilerini paylaşması gerekmektedir. Verilerinizin herhangi bir surette değişikliğe uğraması halinde aşağıda belirtilen iletişim kanallarından bizimle iletişime geçerek verilerinizi güncellemenizi rica ederiz.<br><br><b>11) Kişisel verilerinizle ilgili bilgi</b><br><br>
                Bize kişisel verilerinizle ilgili her türlü soru ve görüşleriniz için info@hediyeurunal.com e-posta adresinden dilediğiniz zaman ulaşabilirsiniz.<br><br></div>
            </div>
        </div>
    </div>
</div>


</template>

<script>
export default {
  name: "Footer"
}
</script>

<style scoped>

.modal-dialog-scrollable .modal-content {
    height: 650px;
}
.modal {
    z-index: 9999999;
}

</style>